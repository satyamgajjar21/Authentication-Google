//jshint esversion:6
//use of dotenv for environment variables
require('dotenv').config()

const express = require("express");
const bodyParser = require("body-parser");
const ejs = require("ejs");
const mongoose = require("mongoose"); //import mongoose to connect with database 
const session = require('express-session'); //Used express session for cookies
const passport = require('passport'); //Used passport session for cookies
const passportLocalMongoose = require('passport-local-mongoose'); //Used passport-local-mongoose session for cookies
const GoogleStrategy = require('passport-google-oauth20').Strategy;
const findOrCreate = require('mongoose-findorcreate');


// const md5 = require("md5"); //use md5  authetication 


const app = express();

// //env
// console.log(process.env.API_KEY);

app.use(express.static("public"));
app.set('view engine', 'ejs');
app.use(bodyParser.urlencoded({
    extended: true
}));


//use the session package
app.use(session({
    secret: "Our Little secret.",
    resave: false,
    saveUninitialized: false
}));

//initialize the paassport
app.use(passport.initialize());
app.use(passport.session());

//use mongoose to connect to the database
mongoose.connect("mongodb://localhost:27017/userDB"); 
 

//create a new schema
const userSchema = new mongoose.Schema ({
    email: String,
    password: String,
    googleId: String
});

userSchema.plugin(passportLocalMongoose); 
userSchema.plugin(findOrCreate); 

 
//use the schema to create the model
const User = new mongoose.model("User", userSchema);

passport.use(User.createStrategy());

passport.serializeUser(function(user, done) {
    done(null, user.id); 
  }); 
  
passport.deserializeUser(function(id, done) {
     // parsed user object will be set to request object field `user`
    User.findById(id, function(err, user){
        done(err,user);
    });
});


//use passport
passport.use(new GoogleStrategy({
    clientID: process.env.CLIENT_ID,
    clientSecret: process.env.CLIENT_SECRET,
    callbackURL: "http://localhost:4000/auth/google/secrets",
    userProfileURL: "https://www.googleapis.com/oauth2/v3/userinfo" 
  },
  function(accessToken, refreshToken, profile, cb) {

    User.findOrCreate({ googleId: profile.id }, function (err, user) {
      return cb(err, user);
    });
  }
));

 
app.get("/", function(req, res){
    res.render("home");
});

//to auth google
app.get('/auth/google',
    passport.authenticate('google', {scope: ["profile"] })
);

//to auth google callback
app.get('/auth/google/secrets',
    passport.authenticate('google', { failureRedirect: '/login'}),
    function(req, res) {
        res.redirect('/secrets');
});
 
 
app.get("/login", function(req, res){
    res.render("login");
});

app.get("/register", function(req, res){
    res.render("register");
});
 
app.get("/secrets", function(req, res){
     if (req.isAuthenticated()){
        res.render("secrets");
     } else {
        res.redirect("/login");
     }
});

//logout  
app.get('/logout', function(req, res, next) {
    req.logout(function(err) {
      if (err) { return next(err); }
      res.redirect('/');
    });
  });
 
// REGISTER //post the data which the user has entered
app.post("/register", function(req,res){
    
    User.register({username: req.body.username}, req.body.password, function(err, user){
        if(err) {
            console.log(err);
            res.redirect("/register");
        } else {
            passport.authenticate("local")(req, res, function(){
                res.redirect("/secrets");
            });
        }
    });
});
 

// LOGIN //post the data which the user has entered
app.post("/login", function(req, res){
    
    const user = new User({
        username: req.body.username,
        password: req.body.password
    });

    req.login(user, function(err){
        if(err){
            console.log(err);
        } else {
            passport.authenticate("local")(req,res, function(){
                res.redirect("/secrets");
            });
        }
    })
});
 



app.listen(4000, function(){
    console.log("Server is running on port 4000");
});
